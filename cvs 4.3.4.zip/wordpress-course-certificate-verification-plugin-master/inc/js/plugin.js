$(document).ready(function() {
	$('#certificates-table').DataTable();
} );